предварительная установка: pip install -r requirements.txt

запуск: python main.py source_files out_files

обрабатывает все файлы в source_files
перед перезапуском надо удалять файлы из директории out_files, (уже обработанные игнорируются а не перезаписываются)

